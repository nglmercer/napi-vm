import importlib.util,json,subprocess
from pathlib import Path
p=Path('/workspace/napi-vm/tools/test262/audit_contextual_bindings.py');spec=importlib.util.spec_from_file_location('audit',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
bodies=['await 0;','yield 0;','yield* [];','super();','super.x;','super[x];','new.target;','this.#x;','#x in this;','break;','continue;','return;','let x; var x;','let x; function x(){}','var x; function x(){}','const x=1; class x{}','let x; let x;','var await;','var yield;','let let;','var eval;','var arguments;','function f(a,a){}','function f(a=1,a){}','try{}catch(x){let x;}','try{}catch(x){var x;}']
wrappers=['{}','function f(){%s}','()=>{%s}','async function f(){%s}','async()=>{%s}','function* f(){%s}','async function* f(){%s}','class C{constructor(){%s}}','class C extends B{constructor(){%s}}','class C{m(){%s}}','class C extends B{m(){%s}}','class C{static{%s}}','class C{#x;m(){%s}}','class C{#x;static m(){%s}}','({m(){%s}});','({async m(){%s}});','({*m(){%s}});','class C{constructor(){()=>{%s}}}','class C extends B{constructor(){()=>{%s}}}','async function f(){()=>{%s}}','function* f(){()=>{%s}}','class C{m(){function f(){%s}}}']
rows=[]
for strict in [False,True]:
 for wi,w in enumerate(wrappers):
  for bi,b in enumerate(bodies):
   source=b if w=='{}' else w%b
   rows.append({'test':f'context-{wi}-{bi}','variant':'strict' if strict else 'script','module':False,'source':('"use strict";' if strict else '')+source})
source='\n'.join(json.dumps(r) for r in rows)+'\n'
def run(cmd):return m.outcomes(subprocess.run(cmd,input=source,text=True,capture_output=True,check=True,timeout=30).stdout,rows)
a=run(['/workspace/napi-vm/artifacts/test262/engines/syntax-audit-32a469b']);b=run(['node','--experimental-vm-modules','-e',m.NODE_DRIVER]);diff=[{**r,'accepted':x['accepted'],'expected':y['accepted'],'error':x.get('error')} for r,x,y in zip(rows,a,b) if x['accepted']!=y['accepted']]
Path('/tmp/napi-grammar-context-probe-32a469b.json').write_text(json.dumps({'total':len(rows),'mismatches':diff},indent=2));print(json.dumps({'total':len(rows),'mismatches':len(diff),'examples':diff[:8]},indent=2))
