import sys,json,time,hashlib
from pathlib import Path
sys.path.insert(0,'tools/test262');from run import run_variant,metadata
root=Path('/workspace/test262');test=root/'test/staging/sm/Proxy/ownkeys-linear.js';source=test.read_text();data=metadata(source);rows=[]
for repeat in range(2):
 for tag in ['193998b','be8ebf3']:
  engine=Path('artifacts/test262/engines')/f'phase1-{tag}-followup-test262'
  for strict in [False,True]:
   started=time.perf_counter();result=run_variant(engine.resolve(),root,test,source,data,'strict' if strict else 'script',strict,5)
   row={'source':tag,'engine_sha256':hashlib.sha256(engine.read_bytes()).hexdigest(),'repeat':repeat,'strict':strict,'elapsed_seconds':time.perf_counter()-started,**result};rows.append(row);print(json.dumps(row),flush=True)
Path('/tmp/napi-ownkeys-timing.json').write_text(json.dumps({'classification':'Isolated timing diagnostic; not a full-corpus result','timeout_seconds':5,'results':rows},indent=2))
