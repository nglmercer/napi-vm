import json,subprocess
from pathlib import Path
source=Path('/workspace/test262/test/staging/sm/Proxy/revoked-get-function-realm-typeerror.js').read_text()
source=source.replace('for (let {constructor, args = []} of constructors) {', 'var probeIndex=0;for (let {constructor, args = []} of constructors) {var index=probeIndex++;')
source=source.replace('assert.sameValue(revoked, 1);', "if (revoked !== 1) throw new Error('Constructor: '+String(constructor && constructor.name)+' index '+index+' prototype trap count: '+revoked);")
harness=Path('/workspace/test262/harness/sta.js').read_text()+'\n'+Path('/workspace/test262/harness/assert.js').read_text()
r=subprocess.run(['/workspace/napi-vm/artifacts/test262/engines/phase1-193998b-followup-test262'],input=json.dumps({'source':source,'harness':harness}),text=True,capture_output=True,timeout=10)
print(r.stdout);print(r.stderr)
